
# Create your models here.
from django.db import models

class Ticket(models.Model):
    name = models.CharField(max_length=200)  # Customer name
    email = models.EmailField()             # Customer email
    price = models.IntegerField()           # Ticket price
    qrcode_image = models.ImageField(upload_to='qrcodes/', blank=True, null=True)  # QR code image

    def __str__(self):
        return f"{self.name} - £{self.price}"
