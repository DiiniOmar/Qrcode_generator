from django.shortcuts import render, redirect
from .forms import TicketForm
from .models import Ticket
import qrcode
from io import BytesIO
from django.core.files.base import ContentFile

def create_ticket(request):
    if request.method == 'POST':
        form = TicketForm(request.POST)
        if form.is_valid():
            
            ticket = form.save(commit=False)

            # Generate QR Code
            qr_data = f"Name: {ticket.name}, Price: £{ticket.price}"
            qr = qrcode.make(qr_data)

            # Save QR Code Image to the ticket model
            buffer = BytesIO()
            qr.save(buffer, format='PNG')
            buffer.seek(0)
            ticket.qrcode_image.save(f"{ticket.name}_qrcode.png", ContentFile(buffer.read()), save=True)
            buffer.close()

            # Save the ticket with the QR code
            ticket.save()
            return redirect('ticket_list')  
    else:
        form = TicketForm()  

    # Render the create_ticket page with the form and any existing tickets
    tickets = Ticket.objects.all()  # Get all tickets to display in the list
    return render(request, 'Ticket/create_ticket.html', {'form': form, 'tickets': tickets})

def ticket_list(request):
    tickets = Ticket.objects.all()  
    return render(request, 'Ticket/ticket_list.html', {'tickets': tickets})
